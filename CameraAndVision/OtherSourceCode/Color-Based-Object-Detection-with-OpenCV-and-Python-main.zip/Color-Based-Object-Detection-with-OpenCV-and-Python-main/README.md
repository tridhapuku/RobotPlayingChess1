# Color-Based Object Detection with OpenCV and Python

This is the repository for the tutorial: https://dontrepeatyourself.org/post/color-based-object-detection-with-opencv-and-python/
